package utils;

public class CountEnglishCharacterNum {
	//统计该字符串有多少英文单个字符
	public static int CountStr(String str) {
		char[] cc=str.toCharArray();
		int n=0;
		for (int i = 0; i < cc.length;i++) {
            if(Character.isUpperCase(cc[i])||Character.isLowerCase(cc[i]))n++;
        }
		return n;
    }
}
