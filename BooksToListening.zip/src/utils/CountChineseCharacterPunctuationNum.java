package utils;

public class CountChineseCharacterPunctuationNum {
	// 统计该字符串有多少中文标点符号
	public static int CountStr_fornovel(String str) {
		int n = 0;
		String p=str;
		String[] arr = p.split("");
		for (int i = 0; i < arr.length; i++) {
			if(arr[i].matches("[。？！，、；：“”‘'（）《》〈〉【】『』「」﹃﹄〔〕…—～﹏￥]"))n++;
			
			//System.out.print();
		}
		return n;
	}
	
}
