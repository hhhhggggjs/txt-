package utils;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileFilter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class Fix_txt_name {

	/*public static void main(String args[]) throws IOException {
		fix("D:\\私人文件夹\\文档\\电子书下载\\epub格式","D:\\私人文件夹\\文档\\桌面图标文件折叠\\其他\\电子书java问题\\2\\yuanjian\\TXT书籍");
		}*/
	//输入需改名的txt文件夹地址list，和含有正确名字的epub文件夹地址list，返回改好名字的字典，key是原需改名的txt文件名，value是更改后的名字
	public static Map<String, String> fix(Map<String, String> map,List<String> txt_list,List<String> epub_list) {
		
		// TODO 自动生成的方法存根
		/*1.根据epub原版地址，list遍历其文件夹epub结尾的所有文件名字，存入数组
		2.根据txt原版地址，list遍历其文件夹txt结尾的所有文件名字
		3.判断是否txt是某一epub的子字符串
		4.是的话将返回epub名字，否的话返回txt原版地址
		5.return到main函数的nickname里
		
		*/
		
		String epubname,txtname,txtname_affix,bookmarkcontent,firstline;
		int countreplace=0;//统计替换成功的次数
		Map<String, String> map_result= map;
		
		for (int i = 0; i < map_result.size(); i++) {
			//System.out.println(list_epub.get(i));
			txtname=(txt_list.get(i)).substring((txt_list.get(i)).lastIndexOf("\\")+1).replaceAll(".txt", "");
			txtname_affix=(String)txt_list.get(i);
			bookmarkcontent=findfirstbookmark(txtname_affix);
			firstline=findfirstline(txtname_affix);
			bookmarkcontent=bookmarkcontent==null?txtname:bookmarkcontent;
			firstline=firstline==null?txtname:firstline;
			int j=epub_list.size();
			
			while (j-->0) {
				epubname=(epub_list.get(j)).substring((epub_list.get(j)).lastIndexOf("\\")+1).replaceAll(".epub", "");
				if(epubname.contains(bookmarkcontent)&&bookmarkcontent!=null) {
					map_result.put(txt_list.get(i), prune_txt_name(bookmarkcontent));
					countreplace++;
				//	System.out.println("按书名号替换成功，原书名："+txtname);
					System.out.println("按书名号重命名成功，新书名："+map_result.get(txt_list.get(i)));
					
					break;
				}
				if(epubname.contains(firstline)&&firstline!=null) {
					map_result.put(txt_list.get(i), prune_txt_name(firstline));
					countreplace++;
				//	System.out.println("按首行字符串替换成功，原书名："+txtname);
					System.out.println("按首行字符串重命名成功，新书名："+map_result.get(txt_list.get(i)));
					
					break;
				}
				if(epubname.contains(txtname)) {
						map_result.put(txt_list.get(i), prune_txt_name(epubname));
						countreplace++;
						//System.out.println("按文件名替换成功，原书名："+txtname);
						System.out.println("按文件名重命名成功，新书名："+map_result.get(txt_list.get(i)));
						break;
				}
				if(j==0) {
					map_result.put(txt_list.get(i), prune_txt_name(txtname));
					System.out.println("该书名未修改，原书名(去除网址)："+prune_txt_name(txtname));
				}
					
			}
			
		}
		System.out.println("有效重命名次数："+countreplace);
		
		
		 /*Iterator it1 = list_result.iterator();
	        while(it1.hasNext()){
	            System.out.println(it1.next());
	        }*/
		
		
		
		return map_result;
	}
	
	private static String prune_txt_name(String txtname) {
		// TODO Auto-generated method stub
		String reg_p = "[。？！，、；：“”‘’（）《》〈〉【】『』「」﹃﹄〔〕…—～﹏￥]";// 中文标点符号正则
		txtname = txtname.replaceAll("([\\u4e00-\\u9fa5]+||" + reg_p
				+ "*)(https?|ftp|file|ww?)://[-A-Za-z0-9+&@#/%?=~_|!:,.;]+[-A-Za-z0-9+&@#/%=~_|]([\\u4e00-\\u9fa5]*||"
				+ reg_p + "*)", "$1$3");
		txtname = txtname.replaceAll("([\\u4e00-\\u9fa5]+||" + reg_p
				+ "*)(https?:\\/\\/)?([\\da-z\\.-]+)\\.([a-z]{2,6})(:\\d{1,5})?([\\/\\w\\.-]*)*\\/?(#[\\S]+)?([\\u4e00-\\u9fa5]+||"
				+ reg_p + "*)", "$1$8");
		//System.out.println("修改后的："+txtname);
		return txtname;
	}

	//输入txt文件名，返回是否包含该txt文件内容第一个书名号内是否匹配，若匹配，返回书名号内容；否则，返回null
	
	private static String findfirstbookmark(String txtfiledir) {
		FileReader reader = null;
		try {
			//System.out.println("txtfilename:"+txtfiledir);
			reader = new FileReader(txtfiledir);
			BufferedReader br = new BufferedReader(reader); // 建立一个对象，它把文件内容转成计算机能读懂的语言
			
			String line="";
			try {
				while ((line=br.readLine())!=null) {
					if(line.contains("《")||line.contains("》")) {//replaceFirst有问题，只能特殊值法了
						line=	line.replaceFirst("(《)","öäöäöä");
						line=	line.replaceFirst("(》)","äöäöäö");
						line=line.replaceFirst("([^äö]+)?(öäöäöä)([^äö]*)(äöäöäö)([^äö]+)?", "$3");
						return line;
					}
				}
			} catch (IOException e) {
				// TODO 自动生成的 catch 块
				System.out.println(e+"函数returnfirstbookmark读入文件出错");
			}
		} catch (FileNotFoundException e) {
			// TODO 自动生成的 catch 块
			System.out.println(e+"函数returnfirstbookmark创建reader或BufferedReader失败");
		}
		
		
			return null;
			
	}
	
	private static String findfirstline(String txtfiledir) {
		FileReader reader = null;
		
		try {
			//System.out.pr ename:"+txtfiledir);
			reader = new FileReader(txtfiledir);
			BufferedReader br = new BufferedReader(reader); // 建立一个对象，它把文件内容转成计算机能读懂的语言
			
			String line="";
			try {
				line=br.readLine();
				br.close();
				return line;
			} catch (IOException e) {
				// TODO 自动生成的 catch 块
				System.out.println(e+"函数returnfirstbookmark读入文件出错");
				return null;
			}
		} catch (FileNotFoundException e) {
			// TODO 自动生成的 catch 块
			System.out.println(e+"函数returnfirstbookmark创建reader或BufferedReader失败");
		}
			return null;
			
	}
	
	
	// 输入txt文件名，返回是否该txt第一个行内容与txt文件名匹配，若匹配，返回第一行内容，否则，返回null
	
		private static List<String> getepubFileList(File file) {
			 
			List<String> result = new ArrayList<String>();
	 
			if (!file.isDirectory()) {
				System.out.println(file.getAbsolutePath());
				result.add(file.getAbsolutePath());
			} else {
				File[] directoryList = file.listFiles(new FileFilter() {
					public boolean accept(File file) {
						if (file.isFile() && file.getName().indexOf("epub") > -1) {
							return true;
						} else {
							return false;
						}
					}
				});
				for (int i = 0; i < directoryList.length; i++) {
					result.add(directoryList[i].getPath());
				}
			}
	 
			return result;
		}
		private static List<String> gettxtFileList(File file) {
			 
			List<String> result = new ArrayList<String>();
	 
			if (!file.isDirectory()) {
				System.out.println(file.getAbsolutePath());
				result.add(file.getAbsolutePath());
			} else {
				File[] directoryList = file.listFiles(new FileFilter() {
					public boolean accept(File file) {
						if (file.isFile() && file.getName().indexOf("txt") > -1) {
							return true;
						} else {
							return false;
						}
					}
				});
				for (int i = 0; i < directoryList.length; i++) {
					result.add(directoryList[i].getPath());
				}
			}
	 
			return result;
		}
}
