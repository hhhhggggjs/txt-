package utils;

public class CountChineseCharacterNum {
	//统计该字符串有多少中文单个字符
	public static int CountStr(String str) {
		char[] cc=str.toCharArray();
		int n=0;
		for (int i = 0; i < cc.length;i++) {
            if(isChinese(cc[i]))n++;
        }
		return n;
	}
	public static boolean isChinese(char c) {
        Character.UnicodeScript sc = Character.UnicodeScript.of(c);
        if (sc == Character.UnicodeScript.HAN) {
            return true;
        }

        return false;
    }
}
