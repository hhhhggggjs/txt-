package utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class FixParenthesesContent {
	// 删除括号间纯英文德文日文等、标点符号、数字。小于等于4位的数字不能删除
	public static String fix(String line) {
		String ll = line;
		String tmpll = ll;// 用于计算汉字数量是否变更

		Pattern r2 = Pattern.compile("([^\\(\\)\\[\\]（）【】])?" + "([\\(（\\[【]{1})" + "([^\\(\\)\\[\\]（）【】]+)"
				+ "([\\)）\\]】]{1})" + "([^\\(\\)\\[\\]（）【】])?");
		Matcher m2 = r2.matcher(ll);
		while (m2.find()) { // find一次可找到第一次 某str的一次reg匹配所有结果
			String tmp = "";// tmp为捕获到的单个,含括号
			String tmp_nude = "";// tmp为捕获到的单个，不含括号
			String t1 = "",t2="";// 将替换的内容
			tmp = m2.group(2).concat(m2.group(3).concat(m2.group(4)));// 括号内的内容
			tmp_nude = tmp.substring(1, tmp.length() - 1);
			// System.out.println(tmp_nude);
			
			//if (tmp.matches("([^\u4e00-\u9fa5]+)") && !tmp.equals("")) {// 不含中文
				if (CountChineseCharacterNum.CountStr(tmp)==0&&!tmp.matches("([\\(（\\[【]{1}"+"[+*\\s]+"+"[\\)）\\]】]{1})+")) {// 不含中文
				//System.out.println(tmp);
					
				if (!tmp.matches("([^\\(\\)\\[\\]（）【】]+)?" + "[\\(（\\[【]{1}" + "([0-9%$￥=，\\,.&&[^\\(\\)\\[\\]（）【】]]+)"+ "[\\)）\\]】]{1}" + "([^\\(\\)\\[\\]（）【】]+)?")&&!tmp_nude.matches("(([A-Za-z]?[\\d.]+%([,\\s]+)?)+)|(([A-Za-z]+=+\\d+([,\\s]+)?)+)")&&!tmp_nude.matches("([\\+\\-][\\d\\.]+)(%?)")) {
					
					
					
					boolean ifmequal2=false;//剔除（m=2,2022,John,m=11.1%,=11）的标志
					String reg_killmequal2="([a-zA-Z]([\\s]?=[\\s]?)+([0-9.]+(%)?))+";//剔除（m=2,2022,John,m=11.1%,=11）的正则
					Pattern r3 = Pattern.compile(reg_killmequal2);//剔除（m=2,2022,John,m=11.1%,=11）
					Matcher m3 = r3.matcher(tmp_nude);
					while(m3.find()) {
						if(m3.group(2).matches("=")) {
							ifmequal2=true;
							break;
						}
					}
					if(!ifmequal2) {
						//System.out.println("tmp:"+tmp);
					
					//专项⑦
						
						try {
							
							ll=ll.replaceAll(tmp_nude, "");//替换
						} catch (Exception e) {
							System.out.println(e);
							System.out.println("当前错误行修改前："+tmpll);
							System.out.println("tmp"+tmp);
							System.out.println("当前错误行修改后："+ll);
						}
					
						
						
						
					//	①System.out.println("进来前的tmp"+tmp);
					if (tmp.matches(("([^\\(\\)\\[\\]（）【】]+)?" + "[\\(（\\[【]{1}" + "([\\sa-zA-Z]+)" + "[\\)）\\]】]{1}"+ "([^\\(\\)\\[\\]（）【】]+)?"))) {
						// System.out.println(tmp);
						ll=ll.replaceAll(tmp_nude, "");//替换
					}
					//②
					if (tmp_nude.matches("([[^\\(\\)\\[\\]（）【】0-9]&&\\s\\x3130-\\x318FüöäßÑа-яА-Яa-zA-Z。？！，、；：“”‘’（）《》〈〉【】『』「」﹃﹄〔〕…—～﹏￥`~!@#^\\&*\\(\\)_+-=\\[\\]{}\\|;':\\\",./<>?]+)?((\\D{1}([1|2][0-9][0-9][0-9]$))|(\\D{1}([1|2][0-9][0-9][0-9])\\D{1})|(^[1|2][0-9][0-9][0-9]\\D{1})|(\\D{1}[1-9][0-9][0-9]\\D{1})|(^[1-9][0-9][0-9]\\D{1})|(\\D{1}[1-9][0-9][0-9]$))([[^\\(\\)\\[\\]（）【】0-9]&&\\s\\x3130-\\x318FüöäßÑа-яА-Яa-zA-Z。？！，、；：“”‘’（）《》〈〉【】『』「」﹃﹄〔〕…—～﹏￥`~!@#^\\&*\\(\\)_+-=\\[\\]{}\\|;':\\\",./<>?]+)?")) {

						// System.out.println(tmp_nude);
						// System.out.println("t1:"+t1);
						
						ll=ll.replaceAll(tmp_nude, "");//替换
						//System.out.println(ll.replaceAll(tmp_nude, "$2"));
					}
					//⑤
					t1=tmp_nude.replaceAll("([[^,，\\s—]\\D+])?([,，\\s—][1|2]\\d\\d\\d)+([^,，\\s—]\\D+)?", "$2");
					t2=tmp_nude.replaceAll("([[^,，\\s—]\\D+])?([1|2]\\d\\d\\d[,，\\s—])+([^,，\\s—]\\D+)?", "$2");
					if(t1!=null||(t2!=null)) {
						try {
							ll=ll.replaceAll(t1, "");//替换
							ll=ll.replaceAll(t2, "");//替换
						} catch (Exception e) {
							System.out.println("t1:"+t1);
							System.out.println("t2:"+t2);
							// TODO 自动生成的 catch 块
							System.out.println("⑤存在错误,已经跳过"+e);
						}
					}
					
					//System.out.println("进来前的ll"+ll);
					// if(tmp_nude.matches("(((\\D{1})([1|2][0-9][0-9][0-9]))|(\\D{1}\\d{4}\\D{1})|(^[0-9]{4}\\D{1})|(\\D{1}[1-9][0-9][0-9])|([1-9][0-9][0-9]\\D{1}))")&&tmp_nude.matches(regex))
				}
				}
			} else if (CountChineseCharacterNum.CountStr(tmp)>0&&!tmp.matches("([\\(（\\[【]{1}"+"[+*\\s]+"+"[\\)）\\]】]{1})+")){// 含中文
				//System.out.println(tmp);
				if (!tmp.matches("([^\\(\\)\\[\\]（）【】]+)?" + "[\\(（\\[【]{1}" + "([0-9%$￥=，\\,.&&[^\\(\\)\\[\\]（）【】]]+)"+ "[\\)）\\]】]{1}" + "([^\\(\\)\\[\\]（）【】]+)?")&&!tmp_nude.matches("(([A-Za-z]?[\\d.]+%([,\\s]+)?)+)|(([A-Za-z]+=+\\d+([,\\s]+)?)+)")) {
					
					//System.out.println(tmp);
					boolean ifmequal2=false;//剔除（m=2,2022,John,m=11.1%,=11）的标志
					String reg_killmequal2="([a-zA-Z]([\\s]?=[\\s]?)+([0-9.]+(%)?))+";//剔除（m=2,2022,John,m=11.1%,=11）的正则
					Pattern r3 = Pattern.compile(reg_killmequal2);//剔除（m=2,2022,John,m=11.1%,=11）
					Matcher m3 = r3.matcher(tmp_nude);
					while(m3.find()) {
						if(m3.group(2).matches("=")) {
							ifmequal2=true;
							break;
						}
					}
					if(!ifmequal2) {
						//⑨专项，删除了【能SaaS力； hsdjffdf dfsf sdf.，2008ister & Dhavale, 2001；】	
						t1=tmp_nude.replaceAll("[a-zA-Z\\s，,。;&]+[.]?[a-zA-Z\\s，,。;&]+([1|2][0-9][0-9][0-9])", "");
						ll=ll.replaceAll(tmp_nude, t1);//替换
						tmp_nude=t1;
						t2=tmp_nude.replaceAll("([1|2][0-9][0-9][0-9])+[a-zA-Z\\s，,。;&]+[.]?[a-zA-Z\\s，,。;&]", "");
						ll=ll.replaceAll(tmp_nude, t2);//替换
						
						
					//③
					if (tmp.matches("([^\\(\\)\\[\\]（）【】]+)?" + "[\\(（\\[【]{1}" + "((([^资料来源|网址]+)?(资料来源|网址)([^资料来源|网址]+)?)+)"+ "[\\)）\\]】]{1}" + "([^\\(\\)\\[\\]（）【】]+)?")&& CountChineseCharacterNum.CountStr(tmp) < 6) {
						 ll=ll.replaceAll(tmp_nude, "");//替换
					}
					//③
					if (tmp.matches("([^\\(\\)\\[\\]（）【】]+)?" + "[\\(（\\[【]{1}" + "((([^比如|如|例如]+)?(比如|如|例如)([^比如|如|例如]+)?)+)"+ "[\\)）\\]】]{1}" + "([^\\(\\)\\[\\]（）【】]+)?") && CountChineseCharacterNum.CountStr(tmp) < 3) {
						 ll = ll.replaceAll(tmp_nude, "");//替换
					}
					//④
					
					if (CountChineseCharacterNum.CountStr(tmp) < 4&&!tmp_nude.matches("[\\d]+年")&&!tmp_nude.matches("[\\u4e00-\\u9fa5]+")) {
						//System.out.println(tmp_nude);
						//System.out.println("替换前："+tmp);
						t1=tmp_nude.replaceAll("([\\d]{3,4}(\\s+)?[,，])", "");
						t2=tmp_nude.replaceAll("([,，](\\s+)?[\\d]{3,4})", "");
						ll=ll.replaceAll(tmp_nude, t1);//替换
						ll=ll.replaceAll(tmp_nude, t2);//替换
						//System.out.println("替换前："+tmp);
					}
					
					
					//专项⑧
					if(!tmp_nude.matches("[\\u4e00-\\u9fa5]+")&&!tmp_nude.matches("[\\d]+年")) {
						//System.out.println(tmp);
						t2=tmp_nude.replaceAll("([A-Za-z-])","");
						ll=ll.replaceAll(tmp_nude, t2);//替换
					}
					
					
					
					
					/*
					 * t1=tmp.replaceAll("[a-zA-Z]+","");//获取无英文的字符串 System.out.println(t1);
					 * ll=ll.replaceAll(tmp, t1);
					 */
				}}
			}

		}

		//if (CountChineseCharacterNum.CountStr(tmpll) != CountChineseCharacterNum.CountStr(ll))System.out.println(tmpll);

		return ll;
	}
}
