
import utils.CountChineseCharacterNum;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileFilter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;

import utils.CountChineseCharacterPunctuationNum;
import utils.CountEnglishCharacterNum;
import utils.FixParenthesesContent;
import utils.Fix_txt_name;
public class Main {//读取文件夹下所有txt的行内数据
	static int count_ll;//统计已经处理到第几次行
	
	
    public static void main(String args[]) throws IOException {
    	//请输入需要转化的txt格式文件夹地址
    	String filedir="D:\\私人文件夹\\文档\\桌面图标文件折叠\\其他\\电子书java问题\\2\\yuanjian\\workpath\\";
    	filedir = "D:\\私人文件夹\\文档\\桌面图标文件折叠\\其他\\电子书java问题\\2\\yuanjian\\workpath\\";//需处理的文件夹目录
    	filedir = "C:\\Users\\Ushop\\Desktop\\新建文件夹";//需处理的文件夹目录
    //	filedir = "D:\\考试资料\\学习\\代码\\yuanjian\\workpath\\";
    //	filedir="D:\\考试资料\\学习\\代码\\yuanjian\\TXT书籍\\";
    	//请输入导出地址
    	String outputdir="C:\\Users\\Ushop\\Desktop\\OUT1";
    	//outputdir="D:\\Users\\User\\Desktop\\out\\";
    	
    	
    	
    	
    	//无需更名的话，下面不用填。 文件名如果有问题，请输入含正确名字的原版epub格式文件夹地址和含错误的原版txt格式文件夹地址
    	String epubdir="D:\\私人文件夹\\文档\\电子书下载\\TXT格式";
    	//String epubdir="D:\\考试资料\\学习\\代码\\yuanjian\\EPUB书籍\\";
    	
    	//优化三个路径
    	outputdir=outputdir.trim();
    	if(!(outputdir.lastIndexOf(-1)=='\\')) {
    		outputdir=outputdir.concat("\\");
    	}
    	if(!checkIfFolderExist(outputdir)) {
    		System.out.println("目标文件夹不存在，自动创建中……");
    		if(!createNewFolder(outputdir)) {
    			System.out.println("目标文件夹创建失败！文件夹：" +outputdir);
    		}else {
    			System.out.println("目标文件夹创建成功！文件夹：" +outputdir);
    		}
    	}
    	if(checkIfFolderExist(filedir)) {
    		if(!checkIfFolderExist(epubdir)) {
    			System.out.println("需提取文件名的源文件夹不存在！文件夹：" +epubdir);
    			System.out.println("是否无需提取文件名的源文件夹？(建议Y)");
    			if(!checkUserIntention()) {
    				System.exit(0);
    			}
    		}
    	}else {
    		System.out.println("需转换的源文件夹不存在！文件夹：" +filedir);
    		System.exit(0);
    	}
    	
    	
    	
    	
    	
    	boolean ifchangefilename=false;//是否需要重命名标记
    	if(!epubdir.equals("")) {
    		ifchangefilename=true;
    	}else {
    		ifchangefilename=false;
    	}
    	
    	
    	
		File f = new File(filedir);//需修改的txt书籍路径
		List<String> list = new ArrayList<String>();
		list = getFileList(f);
		System.out.println("需重命名&需正则处理的txt文件个数： " + list.size());
		
		Map<String,String> map_txt_nickname = new HashMap();//保存需修改的txt的重命名后的文件名
		if(ifchangefilename) {
		File fepub = new File(epubdir);
		List<String> list_epub = new ArrayList<String>();
		list_epub = getepubFileList(fepub);
		
		for(int ii=0;ii<list.size();ii++) {
				map_txt_nickname.put(list.get(ii), (list.get(ii)).substring((list.get(ii)).lastIndexOf("\\")+1).replaceAll(".txt", ""));
		}
		map_txt_nickname = Fix_txt_name.fix(map_txt_nickname,list,list_epub);
		/*System.out.println("后：------------------------------");
		for (Entry<String, String> entry : map_txt_nickname.entrySet()) {
		    System.out.println("Key = " + entry.getKey() + ", Value = " + entry.getValue());
		 
		}*/}else {
			for(int ii=0;ii<list.size();ii++) {
				map_txt_nickname.put(list.get(ii), (list.get(ii)).substring((list.get(ii)).lastIndexOf("\\")+1).replaceAll(".txt", ""));
		}
		}
		
		
		for (int i = 0; i < list.size(); i++) {
			String countfilerepetition[][]= new String[list.size()][2];//重复文件夹命名,[][]
			
			for (int w = 0; w < countfilerepetition.length;w++) {//初始化
				countfilerepetition[i][1]="0";
			}
			String txt_original_name_affix=list.get(i);//d:fjldksj/dsjfkl.txt
			//String txt_original_name=list.get(i).substring(list.get(i).lastIndexOf("\\")+1).replaceAll(".txt", "");//dsjfkl.txt
			
			
			
			//文件名不存在，则添加
			//否则一直判断是否存在，并且writefile也在累加
			String fileroot=outputdir + map_txt_nickname.get(list.get(i))+".txt";//最终需写入的路径
			File writefile = new File(fileroot);
			while(writefile.exists()) {
				countfilerepetition[i][0]=fileroot;
				countfilerepetition[i][1]=String.valueOf(Integer.valueOf(countfilerepetition[i][1])+1);
				writefile = new File(outputdir + map_txt_nickname.get(list.get(i))+"（"+Integer.valueOf(countfilerepetition[i][1])+"）"+".txt");
				fileroot=outputdir + map_txt_nickname.get(list.get(i))+".txt";
				}
			try {
				if(!writefile.exists())writefile.createNewFile();
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				System.out.println("命名错误，创建文件失败");
			}
			
			
			
			// 创建新文件,有同名的文件的话直接覆盖
			// 读取文件

			try (FileReader reader = new FileReader(txt_original_name_affix);
					BufferedReader br = new BufferedReader(reader); // 建立一个对象，它把文件内容转成计算机能读懂的语言
					FileWriter writer = new FileWriter(writefile);
					BufferedWriter out = new BufferedWriter(writer);) {
				String line;
				String cache_line;
				int pre_chinese_num = 0;
				int after_chinese_num = 0;
				int aa = 0;
				int bb = 0;
				int cc = 0;
				int dd = 0;

				while ((line = br.readLine()) != null) {

					pre_chinese_num = pre_chinese_num + CountChineseCharacterNum.CountStr(line);
					aa = aa + CountEnglishCharacterNum.CountStr(line);
					cc = cc + CountChineseCharacterPunctuationNum.CountStr_fornovel(line);

					cache_line = FixStr(line);
					//cache_line = "";
					// System.out.println(line);

					after_chinese_num = after_chinese_num + CountChineseCharacterNum.CountStr(cache_line);
					bb = bb + CountEnglishCharacterNum.CountStr(cache_line);
					dd = dd + CountChineseCharacterPunctuationNum.CountStr_fornovel(cache_line);
					out.write(cache_line + "\n");
					count_ll++;
					out.flush(); // 把缓存区内容压入文件
				}
				
				  System.out.println("---------------------------------------------------------------------------------------------"); 
				  System.out.println("此次处理的书籍："+map_txt_nickname.get(list.get(i)));
				  System.out.println("处理前的中文个数为："+pre_chinese_num);
				  System.out.println("处理后的中文个数为："+after_chinese_num);
				  System.out.println("处理前后的中文差值为："+(pre_chinese_num-after_chinese_num));
				  System.out.println("处理前的英文个数为："+aa); System.out.println("处理后的英文个数为："+bb);
				  System.out.println("处理前的中文标点符号个数为："+cc);
				  System.out.println("处理后的中文标点符号个数为："+dd); System.out.println("---------------------------------------------------------------------------------------------");
				 
			} catch (IOException e) {
				e.printStackTrace();
			}

		}
	}

	private static String FixStr(String line) {
		// 顺序不能改，改了正则表达式将失效
		String ll = line;
		String tmpll = ll;
		// 中文标点符号正则
		String reg_p = "[。？！，、；：“”‘’（）《》〈〉【】『』「」﹃﹄〔〕…—～﹏￥]";
		// 英文标点符号正则
		//String reg_eng_p = "[`~!@#$%^&*()_+-=\\[\\]{}|;':\\\",./<>?]";

		// 删除邮箱
		ll = ll.replaceAll("\\w+([-+.]\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*", "");
		
		// 删除网址
		ll = ll.replaceAll("([\\u4e00-\\u9fa5]+||" + reg_p
				+ "*)(https?|ftp|file|ww?)://[-A-Za-z0-9+&@#/%?=~_|!:,.;]+[-A-Za-z0-9+&@#/%=~_|]([\\u4e00-\\u9fa5]*||"
				+ reg_p + "*)", "$1$3");
		ll = ll.replaceAll("([\\u4e00-\\u9fa5]+||" + reg_p
				+ "*)(https?:\\/\\/)?([\\da-z\\.-]+)\\.([a-z]{2,6})(:\\d{1,5})?([\\/\\w\\.-]*)*\\/?(#[\\S]+)?([\\u4e00-\\u9fa5]+||"
				+ reg_p + "*)", "$1$8");

		// 无括号的：:+中文间英文年代数据删除，有括号不删除
		ll = ll.replaceAll(
				"([\\u4e00-\\u9fa5]+)([:：])([A-Za-z[\\s，,。.&-]&&[^\\u4e00-\\u9fa5]]+[\\d]{3,4}[,，。.]{0,3})+([\\u4e00-\\u9fa5]+)?",
				"$1$2$4");

		// 包含资料来源且汉字数小于五则删除整行
		if ((ll.contains("资料来源：") || ll.contains("资料来源:")) && CountChineseCharacterNum.CountStr(ll) <= 5)
			ll = "";

		// 删除括号间纯英文德文日文等、标点符号、数字。小于等于4位的数字不能删除
		ll = FixParenthesesContent.fix(ll);

		// 若是纯英文行，则删除整行，但只要大于3个汉字就不删，这里删除了中文
		if (CountEnglishCharacterNum.CountStr(ll) > 30 && CountChineseCharacterNum.CountStr(ll) < 4)
			ll = "";

		// 删除注释,若注释在第一个字符，则不删除，保留空格和中英文
		ll = ll.replaceAll("(" + reg_p + "+)" + "(\\s*)(\\[)(\\d+)(\\])(\\s*)([\\x{4e00}-\\x{9fa5}]||[a-zA-Z])",
				"$1$2$6$7");
		ll = ll.replaceAll("([\\x{4e00}-\\x{9fa5}])(\\s*)(\\[)(\\d+)(\\])(\\s*)([\\x{4e00}-\\x{9fa5}]||[a-zA-Z])",
				"$1$2$6$7");
		ll = ll.replaceAll("([\\x{4e00}-\\x{9fa5}])(\\s*)(\\[)(\\d+)(\\])(\\s*)" + "(" + reg_p + "+)", "$1$2$6$7");

		// 删除汉字间空格,保留汉字
		//ll = ll.replaceAll("(?<=[\\x{4e00}-\\x{9fa5}])\\s(?=[\\x{4e00}-\\x{9fa5}])", "");

		// 删除数字间空格
		ll = ll.replaceAll("(?<=\\d)\\s(?=\\d)", "");

		// 修正（，这种类型的括号
		ll = ll.replaceAll("([\\(（\\[【]{1})([\\s]+)?(，|,)", "$1");

		// 删除所有一对的空括号
		ll = ll.replaceAll("\\(\\)", "");
		ll = ll.replaceAll("（）", "");
		ll = ll.replaceAll("\\[\\]", "");
		ll = ll.replaceAll("【】", "");
		
		//删除行尾句号后凭空出现的纯数字
    	ll=ll.replaceAll("([\\u4e00-\\u9fa5\\s])(。)(\\s)?(\\s)?(\\s)?\\d{1,2}$", "$1$2");
		// 中文变动的行输出
		if (CountChineseCharacterNum.CountStr(tmpll) != CountChineseCharacterNum.CountStr(ll))
		//	System.out.println("中文变动的行：" + tmpll);
		if (!tmpll.equals(ll)) {
			//System.out.println("修改前的行" + tmpll);
			//System.out.println("修改后的行" + ll);
		}

		return ll;

	}
	
	private static List<String> getepubFileList(File file) {
		 
		List<String> result = new ArrayList<String>();
 
		if (!file.isDirectory()) {
			System.out.println(file.getAbsolutePath());
			result.add(file.getAbsolutePath());
		} else {
			File[] directoryList = file.listFiles(new FileFilter() {
				public boolean accept(File file) {
					if (file.isFile() && file.getName().indexOf("epub") > -1) {
						return true;
					} else {
						return false;
					}
				}
			});
			for (int i = 0; i < directoryList.length; i++) {
				result.add(directoryList[i].getPath());
			}
		}
 
		return result;
	}

    private static List<String> getFileList(File file) {
		 
		List<String> result = new ArrayList<String>();
 
		if (!file.isDirectory()) {
			System.out.println(file.getAbsolutePath());
			result.add(file.getAbsolutePath());
		} else {
			File[] directoryList = file.listFiles(new FileFilter() {
				public boolean accept(File file) {
					if (file.isFile() && file.getName().indexOf("txt") > -1) {
						return true;
					} else {
						return false;
					}
				}
			});
			for (int i = 0; i < directoryList.length; i++) {
				result.add(directoryList[i].getPath());
			}
		}
 
		return result;
	}
    
    //输入String路径，返回该路径下文件夹是否存在，true为存在
    private static boolean checkIfFolderExist(String path) {
    	File f=new File(path);
    	if(f.exists()) {
    		return true;
    	}
		return false;
    }

    //输入String路径，创建文件夹，true为创建成功
    private static boolean createNewFolder(String path) {
    	File f=new File(path);
    	if(f.mkdir()) {
    		return true;
    	}
    	return false;
    }

  //用户是否要删除文件
  	public static boolean checkUserIntention(){
  				Scanner input = new Scanner(System.in);
  				boolean yn = true; // a flag to control the loop
  				boolean result=false;
  				int count=3;
  				while (yn&&count>0) { // loop until yn is false
  					count--;
  					System.out.println("请输入：(Y/N)");
  					String answer = input.nextLine(); // get user input
  					switch (answer) { // check user input
  					case "Y":
  					case "y":
  					case "是":
  					case "YEP":
  					case "YES":
  					case "yes":
  						yn = false; 
  						result=true;
  						break;
  					case "N":
  					case "n":
  					case "否":
  					case "NO":
  					case "No":
  					case "no":
  					case "nope":
  					case "Nope":
  						yn = false; 
  						break;
  					default:
  						System.out.println("无效输入，请输入y or n 。"); // prompt user again
  						break;
  					}
  				}
  				//System.out.println("结果："+result);
  				return result;
  				
  			}
}